export class Settings {
  public static ImagesPerRow = 5;
  public static ImagesPerPage = 15;
}
