export class ImageFile {
  constructor(public data: string, public name: string) { }
}
