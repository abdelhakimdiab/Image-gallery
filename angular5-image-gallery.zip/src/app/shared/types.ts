import { Image } from './models/image';

export type ImageArray = Array<Image>;
